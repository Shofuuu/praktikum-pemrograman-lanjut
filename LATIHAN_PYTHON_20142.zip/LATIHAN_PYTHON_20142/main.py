import latihan_package_20142.alpha as a
import latihan_package_20142.beta as b

a.alpha_satu()