#!/usr/bin/python3

def beta_satu():
    print("Beta satu")

def beta_dua():
    print("Beta dua")