#!/usr/bin/python3

def alpha_satu():
    print("Alpha satu")

def alpha_dua():
    print("Alpha dua")